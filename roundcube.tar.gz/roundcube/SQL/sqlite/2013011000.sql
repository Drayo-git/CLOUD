-- Updates from version 0.9-beta

CREATE TABLE IF NOT EXISTS system (
  name varchar(64) NOT NULL PRIMARY KEY,
  value text NOT NULL
);
